# -*- coding: utf-8 -*-
import numpy as np
import cv2

sz = 512

def otsu(hist, total):
    """
    http://en.wikipedia.org/wiki/Otsu's_method
    """
    s = 0 # sum
    for i in range(256):
        s += i * hist[i]
        
    sB = 0.0 # 2nd sum
    wB = 0.0
    wF = 0.0
    ma = 0.0 # max
    between = 0.0
    th1 = 0.0
    th2 = 0.0
    
    for i in range(256):
        wB += hist[i]
        
        if(wB == 0):
            continue
        
        wF = total - wB
        
        if(wF == 0):
            break
        
        sB += i * hist[i] 
        mB = sB / wB
        mF = (s - sB) / wF
        between = wB * wF * np.power(mB - mF, 2)
        
        if(between >= ma):
            th1 = i
            if(between > ma):
                th2 = i
            ma = between

    return (th1 + th2) / 2.0
    
def bimodal(img, i):
  #img =  cv2.cvtColor(img, cv2.cv.CV_RGB2GRAY)
  hist, bins = np.histogram(img.flatten(), 256, [0, 256])
  #th = otsu(hist, sz * sz)
  th, im_bw = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)  
  result = {}
  result['type'] = 'i'
  result['name'] = 'r' + str(i)
  result['value'] = str(th)
  return result



    
    
