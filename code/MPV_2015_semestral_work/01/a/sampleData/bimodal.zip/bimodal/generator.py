RawBlameHistory  
#! /usr/bin/python
# -*- coding: utf-8 -*-
# Nacteni knihoven 
import httplib, urllib
import numpy as np
import cv2

count = 10;
package = 5;
size = [256,256]

for i in range(count):
  for j in range(package):
    img = cv2.cv.CreateImage([size], cv2.cv.IPL_DEPTH_8U, ) 
