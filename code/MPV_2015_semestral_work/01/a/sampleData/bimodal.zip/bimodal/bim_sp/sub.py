#! /usr/bin/python
# -*- coding: utf-8 -*-
# Nacteni knihoven 
import SAKo

SAKo.submit('neduchal', 'testing', 'bimodal', '/home/neduchal/Dokumenty/Projekty/mpv/bimodal/bim_sp/bimodal_func.py','bimodal')
